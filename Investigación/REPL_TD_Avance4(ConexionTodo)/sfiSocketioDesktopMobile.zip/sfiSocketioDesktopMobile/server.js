const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const { Client } = require('node-osc');          // ← nuevo

const app = express();
const server = http.createServer(app);
const io = socketIO(server);
const port = 3000;

// Apunta al puerto donde vas a escuchar en TD
const oscClient = new Client('127.0.0.1', 9000);  // ← nuevo

app.use(express.static('public'));

io.on('connection', (socket) => {
    console.log('New client connected');
    socket.on('message', (message) => {
        console.log('Received message =>', message);
        socket.broadcast.emit('message', message);

        // Reenvía el mismo touch hacia TouchDesigner por OSC   ← nuevo
        if (message && message.type === 'touch') {
            oscClient.send('/audience/touch', message.x / 300, message.y / 400);
        }
    });

    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

server.listen(port, () => {
    console.log(`Server is listening on http://localhost:${port}`);
});